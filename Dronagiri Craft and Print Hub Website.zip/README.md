
  # Dronagiri Craft and Print Hub Website

  This is a code bundle for Dronagiri Craft and Print Hub Website. The original project is available at https://www.figma.com/design/HRV0kECd8ouCeXI5Ovhs5W/Dronagiri-Craft-and-Print-Hub-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  